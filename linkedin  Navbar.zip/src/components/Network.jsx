import React from 'react'
import NavBar from './NavBar'

function Network() {
  return (
    <div>
      <NavBar />
      <h1 className="text-center mt-5">Welcome to network page!</h1>
    </div>
  )
}

export default Network
