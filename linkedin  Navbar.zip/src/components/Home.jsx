import React from 'react'
import NavBar from './NavBar'

function Home() {
  return (
    <div>
      <NavBar />
      <h1 className="text-center mt-5">Welcome to our website!</h1>
    </div>
  )
}

export default Home
