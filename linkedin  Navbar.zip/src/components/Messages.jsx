import React from 'react'
import NavBar from './NavBar'

function Messages() {
  return (
    <div>
      <NavBar />
      <h1 className="text-center mt-5">Welcome to message page!</h1>

    </div>
  )
}

export default Messages
